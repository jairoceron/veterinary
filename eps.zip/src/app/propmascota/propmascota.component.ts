import { Component } from '@angular/core';

@Component({
  selector: 'app-propmascota',
  templateUrl: './propmascota.component.html',
  styleUrl: './propmascota.component.css'
})
export class PropmascotaComponent {

}
